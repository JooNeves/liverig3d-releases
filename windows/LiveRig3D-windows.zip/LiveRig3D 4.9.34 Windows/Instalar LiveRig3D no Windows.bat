@echo off
rem LiveRig3D - instalar neste Windows (V4.9.29): copia a app para a pasta dos programas (C:\Programas\LiveRig3D,
rem "C:\Program Files\LiveRig3D"), cria la a pasta "Livraria" (a livraria da app: truss, motores, aparelhos, GDTF) com
rem permissao para os utilizadores gravarem, e poe o atalho no Ambiente de trabalho e no menu Iniciar.
rem Pede autorizacao de administrador (a janela do Windows "Permitir que esta app faca alteracoes?").
rem V4.9.30: com /silent (a atualizacao automatica da app) nao espera por teclas e no fim volta a abrir a app.
setlocal
set "SILENT="
if /I "%~1"=="/silent" set "SILENT=1"
net session >nul 2>&1
if errorlevel 1 (
  echo A pedir autorizacao de administrador...
  if defined SILENT (
    rem (espera que o instalador acabe e abre a app como o utilizador, nao como administrador)
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '/silent' -Verb RunAs -Wait"
    if exist "%ProgramFiles%\LiveRig3D\LiveRig3D.exe" start "" "%ProgramFiles%\LiveRig3D\LiveRig3D.exe"
  ) else (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  )
  exit /b
)
set "SRC=%~dp0app"
set "DST=%ProgramFiles%\LiveRig3D"
for %%E in (LiveRig3D.exe RigCalcDesktop.exe) do (
  tasklist /FI "IMAGENAME eq %%E" | find /I "%%E" >nul
  if not errorlevel 1 (
    echo A LiveRig3D esta aberta: grava o que tiveres e fecha-a antes de instalar.
    if not defined SILENT pause
    exit /b 1
  )
)
if not exist "%SRC%\LiveRig3D.exe" (
  echo Nao encontro a app em "%SRC%".
  if not defined SILENT pause
  exit /b 1
)
echo A copiar para "%DST%"...
rem (a pasta Livraria nao se toca: e a tua livraria)
robocopy "%SRC%" "%DST%" /MIR /XD "%DST%\Livraria" /XF RigCalcDesktop.exe /NJH /NJS /NDL /NFL /NP >nul
if errorlevel 8 (
  echo A copia falhou.
  if not defined SILENT pause
  exit /b 1
)
if not exist "%DST%\Livraria" mkdir "%DST%\Livraria"
rem os utilizadores deste computador podem gravar na livraria
icacls "%DST%\Livraria" /grant *S-1-5-32-545:(OI)(CI)M /T /Q >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$w = New-Object -ComObject WScript.Shell;" ^
  "foreach ($p in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonPrograms'))) {" ^
  "  $s = $w.CreateShortcut((Join-Path $p 'LiveRig3D.lnk'));" ^
  "  $s.TargetPath = '%DST%\LiveRig3D.exe'; $s.WorkingDirectory = '%DST%'; $s.IconLocation = '%DST%\LiveRig3D.exe,0'; $s.Save() }"
echo.
echo Pronto. A LiveRig3D ficou em "%DST%" (livraria em "%DST%\Livraria"),
echo com atalho no Ambiente de trabalho e no menu Iniciar.
echo FIM-OK
if not defined SILENT pause
